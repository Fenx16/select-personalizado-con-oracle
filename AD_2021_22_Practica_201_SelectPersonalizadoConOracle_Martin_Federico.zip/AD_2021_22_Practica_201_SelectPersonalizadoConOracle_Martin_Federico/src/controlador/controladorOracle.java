/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import java.sql.*;
import java.util.ArrayList;

/**
 *
 * @author marti
 */
public class controladorOracle {
    
    public static Connection conexion;
    public static Statement st;
    public static ResultSet rs;
    public static String sentencia;
    public static ResultSetMetaData rsmd;
    
    public boolean Conexion(String host, String puerto, String usuario, String password) {
        boolean cn = false;
        try {
            conexion = DriverManager.getConnection("jdbc:oracle:thin:@" + host + ":" + puerto + ":xe", usuario, password);
            cn = true;
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return cn;
         
    }
    
    public ArrayList mTablas(DatabaseMetaData md) {
        ArrayList<String> tablas = new ArrayList<>();
        String[] tipo = {"TABLE"};
        try {
            md = conexion.getMetaData();
            rs = md.getTables(null, md.getUserName(), "%", tipo);
            while (rs.next()) {
                tablas.add(rs.getString(3));
            }
            return tablas;
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return tablas;
    }
    
    public ArrayList mColumna(DatabaseMetaData md, String tabla) {
        ArrayList<String> columna = new ArrayList<>();
        try {
            md = conexion.getMetaData();
            rs = md.getColumns(null, md.getUserName(), tabla, "%");
            while (rs.next()) {
                columna.add(rs.getString(4));
            }
            return columna;
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return columna;
    }

    public int tColumna(DatabaseMetaData md, String tabla, String columna) {     
        String tipo="";
        int tC=0;
        try {
            md = conexion.getMetaData(); 
            rs = md.getColumns(null, md.getUserName(), tabla, columna);
            while(rs.next()){
                tipo = rs.getString(5);
            }     
            tC = Integer.parseInt(tipo);

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return tC;
    }
    
}